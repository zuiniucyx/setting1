package com.lixun.topic.room

import android.app.Application
import android.content.Context
import com.bumptech.glide.request.RequestOptions
import com.lixun.topic.room.widget.FilletTransform
import com.scwang.smartrefresh.layout.SmartRefreshLayout
import com.scwang.smartrefresh.layout.api.*
import com.scwang.smartrefresh.layout.footer.ClassicsFooter
import com.scwang.smartrefresh.layout.header.ClassicsHeader
import com.zhy.http.okhttp.OkHttpUtils
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Created by ZeroTao on 2017/11/9.
 */
class App : Application(){
    companion object {
        lateinit var context:Context
        //圆角图片显示配置
        val filletOptions:RequestOptions by lazy { RequestOptions().transform(FilletTransform()) }
    }
    override fun onCreate() {
        super.onCreate()
        val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(10000L, TimeUnit.MILLISECONDS)
                .readTimeout(10000L, TimeUnit.MILLISECONDS)
                //其他配置
                .build()
        OkHttpUtils.initClient(okHttpClient)

        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreater(object : DefaultRefreshHeaderCreater {
            override fun createRefreshHeader(context: Context, layout: RefreshLayout): RefreshHeader {
//                layout.setPrimaryColorsId(R.color.top_bar_bg, android.R.color.white)//全局设置主题颜色
                return ClassicsHeader(context)//指定为经典Header，默认是 贝塞尔雷达Header
//                return ClassicsHeader(context).setTimeFormat(DynamicTimeFormat("更新于 %s"))//指定为经典Header，默认是 贝塞尔雷达Header
            }
        })
        //设置全局的Footer构建器
        SmartRefreshLayout.setDefaultRefreshFooterCreater(object : DefaultRefreshFooterCreater {
            override fun createRefreshFooter(context: Context, layout: RefreshLayout): RefreshFooter {
                //指定为经典Footer，默认是 BallPulseFooter
                return ClassicsFooter(context).setDrawableSize(20f)
            }
        })
        context=this
    }
}