package com.lixun.topic.room.ui

import android.os.Build
import android.os.Handler
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.adapter.MainFragmentAdapter
import com.lixun.topic.room.utils.MyToast
import kotlinx.android.synthetic.main.activity_main.*

/**
 * Created by ZeroTao on 2017/11/7.
 */
class MainActivity : BaseActivity(){
    private val fragmentList = mutableListOf<Fragment>()
    private  val handler = Handler()
    private var isExit = false

    override fun init() {
        setContentView(R.layout.activity_main)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        fragmentList.add(TestFragment("消息"))
        fragmentList.add(RoomFragment())
        fragmentList.add(MineFragment())
        pager.offscreenPageLimit = 3
        pager.setPageTransformer(false, null)
        val adapter = MainFragmentAdapter(supportFragmentManager,fragmentList)
        pager.adapter = adapter
        navs.setViewPager(pager)
        navs.setOnPageChangeListener(object:ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(state: Int) {
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
            }

            override fun onPageSelected(position: Int) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    window.decorView.systemUiVisibility = if (position > 0) View.SYSTEM_UI_FLAG_VISIBLE else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                }
            }

        })
    }

    override fun onBackPressed() {
        if(isExit){
            finish()
        }else{
            isExit=true
            handler.postDelayed({
                isExit=false
            },2000)
            MyToast.show("再按一次返回键退出话题房")
        }
    }
}