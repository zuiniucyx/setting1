package com.lixun.topic.room.utils

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.text.TextUtils
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by ZeroTao on 2017/8/22.
 * 设置头像工具类
 */

object CropImageUtils {
    internal var FILE_PROVIDER = "com.lixun.topic.room"
    //照片图片名
    private var photo_image: String? = null
    //截图图片名
    private var crop_image: String? = null
    val REQUEST_IMAGE = 1001
    val REQUEST_CAMERA = 1002
    val REQUEST_CROP = 1003
    //相机拍照默认存储路径
    val PICTURE_DIR = Environment.getExternalStorageDirectory().toString() + "/xinlu/pictures/"

    /**
     * 创建图片的存储路径
     */
    fun createImagePath(imageName: String): String {
        val dir = PICTURE_DIR
        val destDir = File(dir)
        if (!destDir.exists()) {
            destDir.mkdirs()
        }
        var file: File? = null
        if (!TextUtils.isEmpty(imageName)) {
            file = File(dir, imageName)
        }
        return file!!.absolutePath
    }


    /**
     * SD卡是否存在
     */
    val isSdcardExist = Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED

    fun newFile(): File {
        val path = createImagePath("img_" + SimpleDateFormat("yyyy_MMdd_hhmmss").format(Date()) + ".png")
        return File(path)
    }

    /**
     * 压缩图片（质量压缩）
     * @param path
     */
    fun compressImage(path: String, outFile: File) {
        val bitmap = BitmapFactory.decodeFile(path)
        val baos = ByteArrayOutputStream()
        bitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, baos)//质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        var options = 100
        while (baos.toByteArray().size / 1024 > 1024) {  //循环判断如果压缩后图片是否大于1024kb,大于继续压缩
            baos.reset()//重置baos即清空baos
            options -= 10//每次都减少10
            bitmap.compress(Bitmap.CompressFormat.JPEG, options, baos)//这里压缩options%，把压缩后的数据存放到baos中
        }
        try {
            val fos = FileOutputStream(outFile)
            try {
                fos.write(baos.toByteArray())
                fos.flush()
                fos.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }

        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        }

        bitmap?.recycle()
    }

    /**
     * 从相册中选择
     */
    fun openAlbum(activity: Activity) {
        val intent: Intent
        if (Build.VERSION.SDK_INT < 19) {
            intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "image/*"
        } else {
            intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        }
        //        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {//如果大于等于7.0使用FileProvider
        //            Uri uriForFile = getUriForFile(activity, FILE_PROVIDER, galleryFile);
        //            intent.putExtra(MediaStore.EXTRA_OUTPUT, uriForFile);
        //            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        //            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        //        }
        activity.startActivityForResult(intent, REQUEST_IMAGE)
    }

    /**
     * 拍照
     */
    fun takePhoto(activity: Activity) {
        if (!isSdcardExist) {
            MyToast.show("未找到存储卡，无法存储照片！")
            return
        }
        photo_image = createImagePath("img_" + SimpleDateFormat("yyyy_MMdd_hhmmss").format(Date()))
        val file = File(photo_image!!)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {//7.0及以上
            //添加这一句表示对目标应用临时授权该Uri所代表的文件
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            //通过FileProvider创建一个content类型的Uri
            val uri = FileProvider.getUriForFile(activity, FILE_PROVIDER, file)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        } else {
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file))
        }
        try {
            activity.startActivityForResult(intent, REQUEST_CAMERA)
        } catch (anf: ActivityNotFoundException) {
            MyToast.show("摄像头尚未准备好")
        }

    }

    //删除文件并且去掉media数据库
    private fun imgExists(activity: Activity, file: File) {
        if (file.exists()) {
            file.delete()
            activity.contentResolver.delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media.DATA + "=?", arrayOf(file.absolutePath))
        }
    }

    /**
     * 调用系统剪裁功能
     */
    fun cropPicture(activity: Activity, path: String) {
        val file = File(path)
        if (!file.parentFile.exists()) {
            file.parentFile.mkdirs()
        }
        val imageUri: Uri
        val outputUri: Uri

        crop_image = createImagePath("head_pic_" + SimpleDateFormat("yyyy_MMdd_hhmmss").format(Date()) + ".jpeg")
        val crop_img = File(crop_image!!)
        val intent = Intent("com.android.camera.action.CROP")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            //添加这一句表示对目标应用临时授权该Uri所代表的文件
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            //通过FileProvider创建一个content类型的Uri
            imageUri = FileProvider.getUriForFile(activity, FILE_PROVIDER, file)
            outputUri = Uri.fromFile(crop_img)
            //TODO:outputUri不需要ContentUri,否则失败
            //outputUri = FileProvider.getUriForFile(activity, "com.solux.furniture.fileprovider", new File(crop_image));
        } else {
            imageUri = Uri.fromFile(file)
            outputUri = Uri.fromFile(crop_img)
        }
        intent.setDataAndType(imageUri, "image/*")
        intent.putExtra("crop", "true")
        //设置宽高比例
        intent.putExtra("aspectX", 1)
        intent.putExtra("aspectY", 1)
        //设置裁剪图片宽高
        intent.putExtra("outputX", 300)
        intent.putExtra("outputY", 300)
        intent.putExtra("scale", true)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString())
        intent.putExtra("noFaceDetection", true)
        activity.startActivityForResult(intent, REQUEST_CROP)
    }

    /**
     * 拍照/打开相册/剪裁图片的回调
     */
    fun onActivityResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?, listener: OnResultListener?) {
        when (requestCode) {
            REQUEST_CAMERA -> if (!TextUtils.isEmpty(photo_image)) {
                val file = File(photo_image!!)
                if (file.isFile && listener != null)
                    listener.takePhotoFinish(photo_image!!)
            }
            REQUEST_IMAGE -> if (data != null) {
                val uri = data.data
                if (uri != null) {
                    val path = GetPathFromUri.getPath(activity, uri)
                    val file = File(path!!)
                    if (file.isFile && listener != null)
                        listener.selectPictureFinish(path)
                }
            }
            REQUEST_CROP -> if (!TextUtils.isEmpty(crop_image)) {
                val file = File(crop_image!!)
                if (file.isFile && listener != null)
                    listener.cropPictureFinish(crop_image!!)
            }
        }
    }

    interface OnResultListener {
        //拍照回调
        fun takePhotoFinish(path: String)

        //选择图片回调
        fun selectPictureFinish(path: String)

        //截图回调
        fun cropPictureFinish(path: String)
    }
}
