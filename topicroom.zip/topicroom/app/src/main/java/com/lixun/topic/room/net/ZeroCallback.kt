package com.lixun.topic.room.net

import android.app.Activity
import android.app.Dialog
import com.lixun.topic.room.utils.MyToast
import com.lixun.topic.room.utils.Utility
import com.zhy.http.okhttp.callback.Callback
import okhttp3.Call
import okhttp3.Response
import org.json.JSONException
import org.json.JSONObject

/**
 * Created by ZeroTao on 2017/8/24.
 * 封装网络请求返回
 */

abstract class ZeroCallback : Callback<String> {
    val pd: Dialog?
    val context:Activity
//    private var dialog: CustomTipDialog? = null

    constructor(context: Activity) {
        this.pd = null
        this.context = context
    }

    constructor(pd: Dialog, context: Activity) {
        this.pd = pd
        this.context = context
    }

    @Throws(Exception::class)
    override fun parseNetworkResponse(response: Response, id: Int): String {
        return response.body()!!.string()
    }

    override fun onResponse(response: String, id: Int) {
        if (context.isDestroyed) {
            return
        }
        pd?.dismiss()
        Utility.log(response)
        try {
            val json = JSONObject(response)
            val code = json.getInt("code")
            when (code) {
                0 -> onSuccess(json)
                //token过期
//                40030 -> {
//                //防止重复提示
//                    if (dialog != null && dialog!!.isShowing()) {
//                        return
//                    }
//                    dialog = object : CustomTipDialog(context, "验证信息过期，请重新登陆", false) {
//                        fun clickOK() {
//                            BusFactory.getBus().post(MessageEvent(MessageEvent.TAG_LOGOUT))
//                            context!!.startActivity(Intent(context, MainActivity::class.java))
//                        }
//                    }
//                    dialog!!.show()
//                }
                else -> {
                    if (onFailure(code)) {
                        val msg = json.getString("msg")
                        MyToast.show(msg)
                    }
                }
            }
        } catch (e: JSONException) {
            Utility.log(e.toString())
            MyToast.show("服务器出错，请稍候再试")
            onFailure()
        }

    }

    fun onFailure() = Unit

    //异常信息 处理则实现该方法并返回false,不处理则默认Toast显示异常信息
    fun onFailure(code: Int) = true

    @Throws(JSONException::class)
    abstract fun onSuccess(json: JSONObject)

    override fun onError(call: Call, e: Exception, id: Int) {
        //主动取消的请求
        val errMsg = e.localizedMessage
        if ("Socket closed" == errMsg || "Canceled" == errMsg) {
            return
        }
        Utility.log(e.toString())
        if (pd != null) {
            MyToast.show("错误，请检查网络")
            pd.dismiss()
        }
        onFailure()
    }
}
