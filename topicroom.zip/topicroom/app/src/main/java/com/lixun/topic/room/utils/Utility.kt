package com.lixun.topic.room.utils

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.support.v4.app.ActivityCompat
import android.util.Log
import android.view.inputmethod.InputMethodManager
import com.lixun.topic.room.App
import java.security.MessageDigest
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by ZeroTao on 2017/7/27.
 */

object Utility {

    fun dip2px(dipValue: Float): Int {
        val scale = App.context.resources.displayMetrics.density
        return (dipValue * scale + 0.5f).toInt()
    }

    fun px2dip(pxValue: Float): Int {
        val scale = App.context.resources.displayMetrics.density
        return (pxValue / scale + 0.5f).toInt()
    }

    fun px2sp(pxValue: Float): Int {
        val fontScale = App.context.resources.displayMetrics.scaledDensity
        return (pxValue / fontScale + 0.5f).toInt()
    }

    fun sp2px(spValue: Float): Int {
        val fontScale = App.context.resources.displayMetrics.scaledDensity
        return (spValue * fontScale + 0.5f).toInt()
    }

    /**
     * 得到设备屏幕的宽度
     */
    fun getScreenWidth(): Int {
        return App.context.resources.displayMetrics.widthPixels
    }

    /**
     * 得到设备屏幕的高度
     */
    fun getScreenHeight(): Int {
        return App.context.resources.displayMetrics.heightPixels
    }

    // 字符串的MD5
    fun stringMD5(message: String): String {
        var md5str = ""
        try {
            // 创建一个提供信息摘要算法的对象，初始化为md5算法对象
            val md = MessageDigest.getInstance("MD5")
            // 将消息转化为byte数组
            val input = message.toByteArray()
            // 计算后获得字节数组，这就是那128位了
            val buff = md.digest(input)
            // 把数组每一个字节（一个字节占八位）换成16进制连成md5字符串
            md5str = bytesToHex(buff)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return md5str
    }

    /**
     * 二进制转十六进制
     */
    fun bytesToHex(bytes: ByteArray): String {
        val md5str = StringBuffer()
        // 把数组每一字节转换成16进制连成md5字符串
        var digital: Int
        for (i in bytes.indices) {
            digital = bytes[i].toInt()
            if (digital < 0) {
                digital += 256
            }
            if (digital < 16) {
                md5str.append("0")
            }
            md5str.append(Integer.toHexString(digital))
        }
        return md5str.toString().toUpperCase()
    }

    /**
     * UTC时间转换成当地时间
     */
    fun utc2Local(utcTime: String): String {
        val utcFormater = SimpleDateFormat("yyyyMMddHHmm")
        utcFormater.timeZone = TimeZone.getTimeZone("UTC")
        var gpsUTCDate: Date? = null
        try {
            gpsUTCDate = utcFormater.parse(utcTime)
        } catch (e: ParseException) {
            Log.e("cyx", "UTC转当地时间:" + e.toString())
        }

        val localFormater = SimpleDateFormat("yyyy年MM月dd日HH时mm分")
        localFormater.timeZone = TimeZone.getDefault()
        return localFormater.format(gpsUTCDate!!.time)
    }


    /**
     * 验证手机格式
     */
    fun isMobile(number: String): Boolean {
        val num = "^[1][34578]\\d{9}$"//"[1]"代表第1位为数字1，"[358]"代表第二位可以为3、5、8中的一个，"\\d{9}"代表后面是可以是0～9的数字，有9位。
        //matches():字符串是否在给定的正则表达式匹配
        return number.matches(num.toRegex())
    }

    // 判断是否符合身份证号码的规范
    fun isIDCard(IDCard: String): Boolean {
        val IDCardRegex = "(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x|Y|y)$)"
        return IDCard.matches(IDCardRegex.toRegex())
    }

    //关闭虚拟键盘
    fun hideKeyboard(context: Activity) {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (imm.isActive && context.currentFocus != null) {
            if (context.currentFocus!!.windowToken != null) {
                imm.hideSoftInputFromWindow(context.currentFocus!!.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
            }
        }
    }

    fun log(text: String) {
        Log.e("zero", text)
    }

    fun hasPermissions(activity: Activity,perms:Array<String>):Boolean{
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
            return true
        }
        perms.forEach {
            if (ActivityCompat.checkSelfPermission(activity,it) == PackageManager.PERMISSION_DENIED) {
                return false
            }
        }
        return true
    }

}
