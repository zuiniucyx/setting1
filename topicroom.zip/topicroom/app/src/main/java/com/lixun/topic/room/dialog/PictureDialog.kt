package com.lixun.topic.room.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.lixun.topic.room.R
import com.lixun.topic.room.utils.CropImageUtils
import kotlinx.android.synthetic.main.dialog_picture.*

/**
 * Created by ZeroTao on 2017/10/9.
 * 上传图片。选择对话框
 */

class PictureDialog : Dialog, View.OnClickListener {

    val activity:Activity

    constructor(context: Activity):super(context, R.style.customDialog){
        activity = context
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_picture)
        val mWindowAttributes = window!!.attributes
        mWindowAttributes.width = WindowManager.LayoutParams.MATCH_PARENT
        mWindowAttributes.gravity = Gravity.BOTTOM
        take_picture.setOnClickListener(this)
        gallery.setOnClickListener(this)
        cancel.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.take_picture -> {
                CropImageUtils.takePhoto(activity)
                dismiss()
            }
            R.id.gallery -> {
                CropImageUtils.openAlbum(activity)
                dismiss()
            }
            R.id.cancel -> dismiss()
        }
    }
}
