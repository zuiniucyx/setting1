package com.lixun.topic.room.utils

import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import java.lang.reflect.Type

/**
 * Created by ZeroTao on 2017/8/24.
 * new TypeToken<ArrayList></ArrayList><User>>(){}.getType()
 * json解析
</User> */

object GsonProvider {
    val gson = Gson()

    fun toJson(`object`: Any): String {
        return gson.toJson(`object`)
    }

    fun <T> fromJson(json: String, classOfT: Class<T>): T {
        return gson.fromJson(json, classOfT)
    }

    @Throws(JsonSyntaxException::class)
    fun <T> fromJson(json: String, typeOfT: Type): T {
        return gson.fromJson(json, typeOfT)
    }
}
