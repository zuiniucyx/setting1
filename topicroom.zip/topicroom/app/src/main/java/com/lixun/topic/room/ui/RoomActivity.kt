package com.lixun.topic.room.ui

import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.adapter.MsgAdapter
import com.lixun.topic.room.adapter.PeopleAdapter
import com.lixun.topic.room.widget.RoomMorePopup
import kotlinx.android.synthetic.main.activity_room.*

/**
 * Created by ZeroTao on 2017/11/10.
 * 选择标签
 */
class RoomActivity : BaseActivity(), View.OnClickListener {

    private var isSound = true
    private var isSpeak = true
    private val msgAdapter by lazy { MsgAdapter(context) }
    private val morePopup by lazy { RoomMorePopup(context,more,true) }

    override fun init() {
        setContentView(R.layout.activity_room)
        back.setOnClickListener(this)
        rv_people.layoutManager = GridLayoutManager(context, 4)
        rv_people.adapter = PeopleAdapter(context)
        rv_people.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(context)
        //地位到最底部
        layoutManager.stackFromEnd =true
        layoutManager.canScrollVertically()
        rv_msg.layoutManager = layoutManager
        rv_msg.adapter = msgAdapter
        rv_msg.setHasFixedSize(true)

        room_sound.setOnClickListener(this)
        room_speak.setOnClickListener(this)
        room_msg.setOnClickListener(this)
        more.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when(v.id){
            R.id.back-> finish()
            R.id.room_sound -> {
                if(isSound){
                    isSound=false
                    room_sound.setImageResource(R.drawable.room_icon_sound_highlight)
                }else{
                    isSound=true
                    room_sound.setImageResource(R.drawable.room_icon_sound_default)
                }
            }
            R.id.room_speak -> {
                if(isSpeak){
                    isSpeak=false
                    room_speak.setImageResource(R.drawable.room_icon_speak_highlight)
                }else{
                    isSpeak=true
                    room_speak.setImageResource(R.drawable.room_icon_speak_default)
                }
            }
            R.id.room_msg -> msgAdapter.notifyDataSetChanged()
            R.id.more -> {
                morePopup.show()
            }
        }
    }
}