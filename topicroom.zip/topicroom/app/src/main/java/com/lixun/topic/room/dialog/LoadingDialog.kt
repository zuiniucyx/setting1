package com.lixun.topic.room.dialog

import android.app.Dialog
import android.app.ProgressDialog
import android.content.Context
import com.zhy.http.okhttp.request.RequestCall
import okhttp3.Call

/**
 * Created by ZeroTao on 2017/10/21.
 * 加载中对话框
 */

object LoadingDialog {

    fun RequestDialog(context: Context, resId: Int, call: Call?): Dialog {
        return RequestDialog(context, context.getString(resId), call)
    }
    fun RequestDialog(context: Context, resId: Int, call: RequestCall?): Dialog {
        return RequestDialog(context, context.getString(resId), call)
    }

    fun RequestDialog(context: Context, msg: String, call: Call?): Dialog {
        val pd = ProgressDialog(context)
        pd.setCanceledOnTouchOutside(false)
        pd.setMessage(msg)
        pd.setOnCancelListener {
            //取消网络请求
            call?.cancel()
        }
        return pd
    }
    fun RequestDialog(context: Context, msg: String, call: RequestCall?): Dialog {
        val pd = ProgressDialog(context)
        pd.setCanceledOnTouchOutside(false)
        pd.setMessage(msg)
        pd.setOnCancelListener {
            //取消网络请求
            call?.cancel()
        }
        return pd
    }
}
