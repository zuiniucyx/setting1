package com.lixun.topic.room.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.KeyEvent
import android.view.WindowManager


/**
 * Created by ZeroTao on 2017/11/7.
 */
abstract class BaseActivity : AppCompatActivity(){
    val context : Activity by lazy { this }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //禁用横屏
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }
        init()
    }

    abstract fun init()

    //MENU键崩溃解决
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if(keyCode == KeyEvent.KEYCODE_MENU){
            //拦截菜单键
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}