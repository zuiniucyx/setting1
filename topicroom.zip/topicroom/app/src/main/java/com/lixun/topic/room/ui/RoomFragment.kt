package com.lixun.topic.room.ui

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.adapter.RoomAdapter
import com.lixun.topic.room.dialog.AddRoomDialog
import com.lixun.topic.room.widget.RoomItemDecoration
import kotlinx.android.synthetic.main.fragment_room.*

/**
 * Created by ZeroTao on 2017/11/17.
 */
class RoomFragment :LazyFragment(), View.OnClickListener {
    private val createRoomDialog by lazy{ AddRoomDialog(context!!)  }

    override fun onClick(v: View) {
        when(v.id){
            R.id.nav1 -> startActivity(Intent(context,NavListActivity::class.java).putExtra("index",0))
            R.id.nav2 -> startActivity(Intent(context,NavListActivity::class.java).putExtra("index",1))
            R.id.nav3 -> startActivity(Intent(context,NavListActivity::class.java).putExtra("index",2))
            R.id.nav4 -> startActivity(Intent(context,MeetingActivity::class.java))
            R.id.add_room -> createRoomDialog.show()
        }
    }

    override fun onCreateViewLazy(savedInstanceState: Bundle?) {
        setContentView(R.layout.fragment_room)
        val itemDecoration = RoomItemDecoration()
        //最热房间
        rv_hot.layoutManager = GridLayoutManager(context, 3)
        rv_hot.adapter = RoomAdapter(context!!)
        rv_hot.setHasFixedSize(true)
        rv_hot.addItemDecoration(itemDecoration)
        more_hot.setOnClickListener(this)
        //最新房间
        rv_new.layoutManager = GridLayoutManager(context, 3)
        rv_new.adapter = RoomAdapter(context!!)
        rv_new.setHasFixedSize(true)
        rv_new.addItemDecoration(itemDecoration)
        more_new.setOnClickListener(this)

        nav1.setOnClickListener(this)
        nav2.setOnClickListener(this)
        nav3.setOnClickListener(this)
        nav4.setOnClickListener(this)
        add_room.setOnClickListener(this)
    }
}