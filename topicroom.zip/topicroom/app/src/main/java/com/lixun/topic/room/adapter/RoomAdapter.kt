package com.lixun.topic.room.adapter

import android.app.Activity
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.lixun.topic.room.R
import com.lixun.topic.room.ui.RoomActivity
import java.util.*

/**
 * Created by ZeroTao on 2017/11/15.
 */
class RoomAdapter :RecyclerView.Adapter<RoomAdapter.ViewHolder> {
    private val context:Activity
    private val inflater:LayoutInflater
    var count = 6

    constructor(context: Activity){
        this.context = context
        inflater = LayoutInflater.from(context)
    }

    override fun getItemCount() = count

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        Glide.with(context).load().apply(App.filletOptions).into(holder.img)
        holder.lock.visibility = if (Random().nextInt(2) == 0) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener({
            context.startActivity(Intent(context,RoomActivity::class.java))
        })
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder =
            ViewHolder(inflater.inflate(R.layout.item_room,null))

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val img: ImageView = itemView.findViewById(R.id.room_img)
        val name: TextView = itemView.findViewById(R.id.room_name)
        val lock: ImageView = itemView.findViewById(R.id.room_lock)
    }

}