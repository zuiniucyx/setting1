package com.lixun.topic.room.adapter

import android.app.Activity
import android.support.v7.widget.RecyclerView
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.lixun.topic.room.R

/**
 * Created by ZeroTao on 2017/11/15.
 */
class MsgAdapter :RecyclerView.Adapter<MsgAdapter.ViewHolder> {
    private val context:Activity
    private val inflater:LayoutInflater
    private val span:ForegroundColorSpan


    constructor(context: Activity){
        this.context = context
        inflater = LayoutInflater.from(context)
        span = ForegroundColorSpan(context.getColor(R.color.top_bar_bg))
    }

    override fun getItemCount(): Int = 111

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val builder = SpannableStringBuilder();
        val nickname = "赵乐乐${position+1}号"
        builder.append(nickname);
        builder.append(": ");
        builder.append("基本信息 姓名:网易云信 生日:2015年10月13日 星座:天秤座 家庭关系 爹:网易(杭州)...");
        builder.setSpan(span, 0, nickname.length, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        (holder.itemView as TextView).text = builder
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder =
            ViewHolder(inflater.inflate(R.layout.item_msg,null))

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){}


}