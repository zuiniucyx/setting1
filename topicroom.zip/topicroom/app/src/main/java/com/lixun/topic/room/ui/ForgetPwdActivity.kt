package com.lixun.topic.room.ui

import android.os.Build
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import com.lixun.topic.room.R
import kotlinx.android.synthetic.main.activity_regist.*

/**
 * Created by ZeroTao on 2017/11/15.
 * 找回密码
 */
class ForgetPwdActivity :BaseActivity(), View.OnClickListener {
    var isShowPwd = false

    override fun onClick(v: View) {
        when(v.id){
            R.id.btn -> {
//                startActivity(Intent(context,RegistInfoActivity::class.java))
                finish()
            }
            R.id.back -> finish()
            R.id.show_pwd -> {
                if (isShowPwd) {
                    et_pwd.transformationMethod = PasswordTransformationMethod.getInstance()
                } else {
                    et_pwd.transformationMethod = HideReturnsTransformationMethod.getInstance()
                }
                et_pwd.setSelection(et_pwd.text.length)
                isShowPwd = !isShowPwd
            }
        }
    }

    override fun init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        setContentView(R.layout.activity_forget_pwd)
        pin.setOnClickListener(this)
        show_pwd.setOnClickListener(this)
        back.setOnClickListener(this)
        btn.setOnClickListener(this)
    }
}