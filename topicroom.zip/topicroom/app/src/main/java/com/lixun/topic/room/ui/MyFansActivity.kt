package com.lixun.topic.room.ui

import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.adapter.FansAdapter
import com.lixun.topic.room.widget.HorizontalItemDecoration
import com.scwang.smartrefresh.layout.api.RefreshLayout
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadmoreListener
import kotlinx.android.synthetic.main.activity_my_fans.*

/**
 * Created by ZeroTao on 2017/11/15.
 * 我的关注
 */
class MyFansActivity :BaseActivity(), View.OnClickListener {

    val isFocus:Boolean by lazy{intent.getBooleanExtra("isFocus",false)}

    override fun onClick(v: View) {
        when(v.id){
            R.id.back -> finish()
        }
    }

    override fun init() {
        setContentView(R.layout.activity_my_fans)
        back.setOnClickListener(this)
        tv_title.text = if (isFocus) "我的关注（111人）" else "我的粉丝（111人）"
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = FansAdapter(context)
        // 如果可以确定每个item的高度是固定的，设置这个选项可以提高性能
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(HorizontalItemDecoration(R.color.line_bg,0.5f))
        refreshLayout.setOnRefreshLoadmoreListener(object :OnRefreshLoadmoreListener{
            override fun onLoadmore(refreshlayout: RefreshLayout) {
            }

            override fun onRefresh(refreshlayout: RefreshLayout) {
            }
        })
    }
}