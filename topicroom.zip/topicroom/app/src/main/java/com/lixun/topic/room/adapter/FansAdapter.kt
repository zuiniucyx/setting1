package com.lixun.topic.room.adapter

import android.app.Activity
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.lixun.topic.room.R
import com.lixun.topic.room.dialog.CustomDialog
import java.util.*

/**
 * Created by ZeroTao on 2017/11/15.
 */
class FansAdapter :RecyclerView.Adapter<FansAdapter.ViewHolder> {
    val context:Activity
    val inflater:LayoutInflater
    val text_color_red:Int
    val text_color_blue:Int

    constructor(context: Activity){
        this.context = context
        inflater = LayoutInflater.from(context)
        text_color_red = context.resources.getColor(R.color.top_bar_bg,null)
        text_color_blue = context.resources.getColor(R.color.tab_blue,null)
    }

    override fun getItemCount(): Int = 111

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if(Random().nextInt(2) == 0){
            holder.btn.setBackgroundResource(R.drawable.fans_btn_blue)
            holder.btn.text = "互相关注"
            holder.btn.setTextColor(text_color_blue)
        }else{
            holder.btn.setBackgroundResource(R.drawable.fans_btn_red)
            holder.btn.text = "取消关注"
            holder.btn.setTextColor(text_color_red)
            holder.btn.setOnClickListener({
                object: CustomDialog(context,"确认取消关注此人？"){
                    override fun clickOK() {

                    }
                }.show()
            })
        }
        holder.gender.setImageResource(if (Random().nextInt(2) == 0) R.drawable.gender_man else R.drawable.gender_woman)
        holder.tv_id.text = "ID:123456$position"
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder =
            ViewHolder(inflater.inflate(R.layout.item_fans,null))

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val nickname: TextView = itemView.findViewById(R.id.nickname)
        val head_pic: ImageView = itemView.findViewById(R.id.head_pic)
        val gender: ImageView = itemView.findViewById(R.id.gender)
        val tv_id: TextView = itemView.findViewById(R.id.tv_id)
        val btn: TextView = itemView.findViewById(R.id.btn)
    }


}