//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.lixun.topic.room.ui

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.FrameLayout.LayoutParams

open class LazyFragment : Fragment() {
    private val STATE_VISIBLE = 1
    private val STATE_NO_SET = -1
    private val STATE_NO_VISIBLE = 0
    private val TAG_ROOT_FRAMELAYOUT = "tag_root_framelayout"

    protected var inflater: LayoutInflater? = null
    protected var context: Activity? = null
    protected var rootView: View? = null
        private set
    private var container: ViewGroup? = null
    private var isInitReady = false
    private var isVisibleToUserState = -1
    private var saveInstanceState: Bundle? = null
    private val isLazyEnable = true
    private var isStart = false
    private val layout: FrameLayout by lazy { FrameLayout(context) }

    protected val realRootView: View?
        get() =
            if (this.rootView != null && this.rootView is FrameLayout && "tag_root_framelayout" == this.rootView!!.tag) (this.rootView as FrameLayout).getChildAt(0) else this.rootView

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        this.inflater = inflater
        this.container = container
        this.onCreateView(savedInstanceState)
        return if (this.rootView == null) super.onCreateView(inflater, container, savedInstanceState) else this.rootView
    }

    private fun onCreateView(savedInstanceState: Bundle?) {
        this.saveInstanceState = savedInstanceState
        val isVisible: Boolean
        if (this.isVisibleToUserState == -1) {
            isVisible = this.userVisibleHint
        } else {
            isVisible = this.isVisibleToUserState == 1
        }

        if (this.isLazyEnable) {
            if (isVisible && !this.isInitReady) {
                this.onCreateViewLazy(savedInstanceState)
                this.isInitReady = true
            } else {
                var mInflater = this.layoutInflater
                if (mInflater == null && this.context != null) {
                    mInflater = LayoutInflater.from(this.context)
                }

                this.layout.tag = TAG_ROOT_FRAMELAYOUT
                val view = this.getPreviewLayout(mInflater, this.layout)
                if (view != null) {
                    this.layout.addView(view)
                }

                this.layout.layoutParams = LayoutParams(-1, -1)
                this.setContentView(this.layout)
            }
        } else {
            this.onCreateViewLazy(savedInstanceState)
            this.isInitReady = true
        }

    }

    protected fun `$`(id: Int): View? {
        return if (this.rootView != null) this.rootView!!.findViewById(id) else null
    }

    protected fun setContentView(layoutResID: Int) {
        if (this.isLazyEnable && this.rootView != null && this.rootView!!.parent != null) {
            this.layout.removeAllViews()
            val view = this.layoutInflater!!.inflate(layoutResID, this.layout, false)
            this.layout.addView(view)
        } else {
            this.rootView = this.layoutInflater!!.inflate(layoutResID, this.container, false)
        }

    }

    protected fun setContentView(view: View) {
        if (this.isLazyEnable && this.rootView != null && this.rootView!!.parent != null) {
            this.layout.removeAllViews()
            this.layout.addView(view)
        } else {
            this.rootView = view
        }

    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        this.isVisibleToUserState = if (isVisibleToUser) 1 else 0
        if (isVisibleToUser && !this.isInitReady && this.rootView != null) {
            this.isInitReady = true
            this.onCreateViewLazy(this.saveInstanceState)
            this.onResumeLazy()
        }

        if (this.isInitReady && this.rootView != null) {
            if (isVisibleToUser) {
                this.isStart = true
                this.onStartLazy()
            } else {
                this.isStart = false
                this.onStopLazy()
            }
        }

    }

    override fun onResume() {
        super.onResume()
        if (this.isInitReady) {
            this.onResumeLazy()
        }

    }

    override fun onPause() {
        super.onPause()
        if (this.isInitReady) {
            this.onPauseLazy()
        }

    }

    override fun onStart() {
        super.onStart()
        if (this.isInitReady && !this.isStart && this.userVisibleHint) {
            this.isStart = true
            this.onStartLazy()
        }

    }

    override fun onStop() {
        super.onStop()
        if (this.isInitReady && this.isStart && this.userVisibleHint) {
            this.isStart = false
            this.onStopLazy()
        }

    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        if (context is Activity) {
            this.context = context
        }

    }

    override fun onDetach() {
        super.onDetach()
        this.context = null

        try {
            val childFragmentManager = Fragment::class.java.getDeclaredField("mChildFragmentManager")
            childFragmentManager.isAccessible = true
            childFragmentManager.set(this, null as Any?)
        } catch (var2: NoSuchFieldException) {
            throw RuntimeException(var2)
        } catch (var3: IllegalAccessException) {
            throw RuntimeException(var3)
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        this.rootView = null
        this.container = null
        this.inflater = null
        if (this.isInitReady) {
            this.onDestoryLazy()
        }

        this.isInitReady = false
    }

    open fun getPreviewLayout(mInflater: LayoutInflater?, layout: FrameLayout) = null

    open fun onCreateViewLazy(savedInstanceState: Bundle?) {}

    open fun onStartLazy() {}

    open fun onStopLazy() {}

    open fun onResumeLazy() {}

    open fun onPauseLazy() {}

    open fun onDestoryLazy() {}

}
