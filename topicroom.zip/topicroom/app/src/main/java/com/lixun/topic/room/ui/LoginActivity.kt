package com.lixun.topic.room.ui

import android.content.Intent
import android.os.Build
import android.view.View
import com.lixun.topic.room.R
import kotlinx.android.synthetic.main.activity_login.*

/**
 * Created by ZeroTao on 2017/11/8.
 */
class LoginActivity:BaseActivity(), View.OnClickListener {
    override fun onClick(v: View) {
        when(v.id){
            R.id.btn -> {
                startActivity(Intent(context,MainActivity::class.java))
                finish()
            }
            R.id.regist -> startActivity(Intent(context,RegistActivity::class.java))
            R.id.forget_pwd -> startActivity(Intent(context,ForgetPwdActivity::class.java))
        }
    }

    override fun init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        setContentView(R.layout.activity_login)
        btn.setOnClickListener(this)
        regist.setOnClickListener(this)
        forget_pwd.setOnClickListener(this)
        qq_login.setOnClickListener(this)
        wx_login.setOnClickListener(this)
    }
}