package com.lixun.topic.room.adapter

import android.app.Activity
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.lixun.topic.room.R

/**
 * Created by ZeroTao on 2017/11/15.
 */
class PeopleAdapter :RecyclerView.Adapter<PeopleAdapter.ViewHolder> {
    val context:Activity
    val inflater:LayoutInflater

    constructor(context: Activity){
        this.context = context
        inflater = LayoutInflater.from(context)
    }

    override fun getItemCount(): Int = 11

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder =
            ViewHolder(inflater.inflate(R.layout.item_people,null))

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val head_pic: ImageView = itemView.findViewById(R.id.head_pic)
        val nickname: TextView = itemView.findViewById(R.id.nickname)
    }


}