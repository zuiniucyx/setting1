package com.lixun.topic.room.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import com.lixun.topic.room.R

/**
 * Created by ZeroTao on 2017/11/10.
 */

class WrapViewGroup @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0) : ViewGroup(context, attrs, defStyleAttr) {
    private val spacingVertical:Float
    private val spacingHorizontal:Float

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.WrapViewGroup)
        spacingHorizontal = a.getDimension(R.styleable.WrapViewGroup_spacing_horizontal, 20f)
        spacingVertical = a.getDimension(R.styleable.WrapViewGroup_spacing_vertical, 20f)
        a.recycle()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val childCount = childCount
        val autualWidth = r - l - paddingRight
        var x = paddingLeft// 横坐标开始
        var y = 0//纵坐标开始
        var rows = 1
        for (i in 0 until childCount) {
            val view = getChildAt(i)
            val width = view.measuredWidth
            val height = view.measuredHeight
            x += width
            if (x > autualWidth) {
                x = width + paddingLeft
                rows++
            }
            y = rows * height + (rows - 1) * spacingVertical.toInt() + paddingTop

            view.layout(x - width, y - height, x, y)

            x += spacingHorizontal.toInt()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var x = 0//横坐标
        var y = 0//纵坐标
        var rows = 1//总行数
        val specWidth = View.MeasureSpec.getSize(widthMeasureSpec)
        val actualWidth = specWidth - paddingLeft - paddingRight//实际宽度
        val childCount = childCount
        for (index in 0 until childCount) {
            val child = getChildAt(index)
            child.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            val width = child.measuredWidth
            val height = child.measuredHeight
            x += width
            if (x > actualWidth) {//换行
                x = width
                rows++
            }
            x += spacingHorizontal.toInt()

            y = rows * height + (rows - 1) * spacingVertical.toInt() + paddingTop + paddingBottom
        }
        setMeasuredDimension(specWidth, y)
    }

}
