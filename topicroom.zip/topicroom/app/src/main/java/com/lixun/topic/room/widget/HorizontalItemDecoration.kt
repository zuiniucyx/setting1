package com.lixun.topic.room.widget

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.support.annotation.ColorRes
import android.support.v7.widget.RecyclerView
import android.view.View
import com.lixun.topic.room.App
import com.lixun.topic.room.utils.Utility

/**
 * Created by ZeroTao on 2017/11/17.
 * RecyclerView 分割线
 */
class HorizontalItemDecoration :RecyclerView.ItemDecoration {
    private val dividerHeight:Int
    private val dividerPaint = Paint()

    constructor(@ColorRes colorRes: Int, dp:Float){
        dividerPaint.color = App.context.resources.getColor(colorRes)
        this.dividerHeight= Utility.dip2px(dp)
    }

    override fun getItemOffsets(outRect: Rect, view: View?, parent: RecyclerView?, state: RecyclerView.State?) {
        outRect.bottom = dividerHeight
    }

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State?) {
        val childCount = parent.childCount
        val left = parent.paddingLeft.toFloat()
        val right = (parent.width - parent.paddingRight).toFloat()

        for(i in 0 until childCount){
            val view = parent.getChildAt(i)
            val top = view.bottom.toFloat();
            val bottom = top + dividerHeight;
            c.drawRect(left, top, right, bottom, dividerPaint);
        }

    }
}