package com.lixun.topic.room.ui

import android.content.Intent
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.dialog.CustomDialog
import kotlinx.android.synthetic.main.activity_setting.*

/**
 * Created by ZeroTao on 2017/11/8.
 */
class SettingActivity :BaseActivity(), View.OnClickListener {
    override fun onClick(v: View) {
        when(v.id){
            R.id.logout -> {
                object: CustomDialog(context, "确认退出登录?"){
                    override fun clickOK() {
                        finish()
                    }
                }.show()
            }
            R.id.back -> finish()
            R.id.setting1 -> startActivity(Intent(context,InfoActivity::class.java))
            R.id.setting2 -> startActivity(Intent(context,ForgetPwdActivity::class.java))
            R.id.setting4 -> startActivity(Intent(context,FeedbackActivity::class.java))
        }
    }

    override fun init() {
        setContentView(R.layout.activity_setting)
        setting1.setOnClickListener(this)
        setting2.setOnClickListener(this)
        setting3.setOnClickListener(this)
        setting4.setOnClickListener(this)
        setting5.setOnClickListener(this)
        back.setOnClickListener(this)
        logout.setOnClickListener(this)
    }
}