package com.lixun.topic.room.net

import android.app.Activity
import android.app.Dialog
import com.lixun.topic.room.utils.MyToast
import com.lixun.topic.room.utils.Utility
import okhttp3.Call
import okhttp3.Response
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * Created by ZeroTao on 2017/9/5.
 * 封装json网络请求返回
 */

abstract class JsonCallback(val pd: Dialog?, val activity: Activity) : okhttp3.Callback {

    override fun onFailure(call: Call, e: IOException) {
        //主动取消的请求
        val errMsg = e.localizedMessage
        if ("Socket closed" == errMsg || "Canceled" == errMsg) {
            return
        }
        Utility.log(e.toString())
        activity.runOnUiThread {
            if (pd != null) {
                MyToast.show("错误，请检查网络")
                pd.dismiss()
            }
            onFailure()
        }
    }

    @Throws(IOException::class)
    override fun onResponse(call: Call, resp: Response) {
        val response = resp.body()!!.string()
        if (activity.isDestroyed) {
            return
        }
        activity.runOnUiThread {
            pd?.dismiss()
            try {
                Utility.log(response)
                val json = JSONObject(response)
                val code = json.getInt("code")
                when (code) {
                    0 -> onSuccess(json)
                    40030     //token过期
                    -> {
                    }
                    else -> {
                        if (onFailure(code)) {
                            val msg = json.getString("msg")
                            MyToast.show(msg)
                        }
                    }
                }//防止重复提示
                //                            if(dialog!=null&&dialog.isShowing()){
                //                                return;
                //                            }
                //                            dialog = new CustomTipDialog(activity,"验证信息过期，请重新登陆",false){
                //                                @Override
                //                                public void clickOK() {
                //                                    BusFactory.getBus().post(new MessageEvent(MessageEvent.TAG_LOGOUT));
                //                                    activity.startActivity(new Intent(activity, MainActivity.class));
                //                                }
                //                            };
                //                            dialog.show();
            } catch (e: Exception) {
                Utility.log("JSONException:" + e.toString())
                MyToast.show("服务器出错，请稍候再试")
                onFailure()
            }
        }
    }

    //异常信息 处理则实现该方法并返回false,不处理则默认Toast显示异常信息
    open fun onFailure(code: Int) = true

    @Throws(JSONException::class)
    abstract fun onSuccess(json: JSONObject)

    open fun onFailure() = Unit
}
