package com.lixun.topic.room.ui

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.ViewGroup

/**
 * Created by ZeroTao on 2017/11/7.
 */
abstract class BaseFragment : Fragment(){
    var context:Activity?=null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) = inflater.inflate(layoutId(),null)!!

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        initData()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if(context is Activity){
            this.context = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        context = null
    }

    abstract fun initData()

    abstract fun layoutId():Int
}