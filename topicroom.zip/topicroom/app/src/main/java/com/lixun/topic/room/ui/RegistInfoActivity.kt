package com.lixun.topic.room.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.support.v4.app.ActivityCompat
import android.view.View
import com.bigkoo.pickerview.OptionsPickerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.lixun.topic.room.AppConstant
import com.lixun.topic.room.R
import com.lixun.topic.room.dialog.PictureDialog
import com.lixun.topic.room.utils.CropImageUtils
import com.lixun.topic.room.utils.MyToast
import com.lixun.topic.room.utils.Utility
import kotlinx.android.synthetic.main.activity_regist_info.*

/**
 * Created by ZeroTao on 2017/11/9.
 * 填写资料
 */
class RegistInfoActivity : BaseActivity(), View.OnClickListener{
    val sexList = listOf("男","女")
    val occupationList = listOf(
            "计算机/互联网/通信",
            "生产/工艺/制造",
            "医疗/护理/制药",
            "金融/银行/投资/保险",
            "商业/服务业/个体经营",
            "文化/广告/传媒",
            "娱乐/艺术/表演",
            "律师/法务",
            "教育/培训",
            "公务员/行政/事业单位",
            "模特",
            "空姐",
            "学生",
            "其他"
    )
    val sexPV by lazy{
        OptionsPickerView.Builder(this , OptionsPickerView.OnOptionsSelectListener {
            options1, _, _, _ -> tv_sex.text = sexList.get(options1) }).setTitleText("选择性别").build()
    }
    val occupationPV by lazy{
        OptionsPickerView.Builder(this , OptionsPickerView.OnOptionsSelectListener {
            options1, _, _, _ -> tv_occupation.text = occupationList.get(options1) }).setTitleText("选择行业").build()
    }
    val dialog by lazy{ PictureDialog(context) }
    val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE)
    val isNeedPerms by lazy{ Utility.hasPermissions(context, perms) }
    lateinit var picPath:String
    val LABE_REQUEST_CODE =1
    var labes:Array<String>?=null

    override fun onClick(v: View) {
        when(v.id){
            R.id.btn -> {
                finish()
            }
            R.id.back -> finish()
            R.id.sex -> {
                Utility.hideKeyboard(context)
                sexPV.show()
            }
            R.id.occupation -> occupationPV.show()
            R.id.head_pic -> {
                if(isNeedPerms) {
                    dialog.show()
                }else{
                    ActivityCompat.requestPermissions(context,perms, AppConstant.PERM_REQUEST_CODE)
                }
            }
            R.id.labe -> startActivityForResult(Intent(context,LabellingActivity::class.java),LABE_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == AppConstant.PERM_REQUEST_CODE){
            if (grantResults.contains(PackageManager.PERMISSION_DENIED)) {
                MyToast.show("权限被禁用，请到设置里打开")
            } else {
                dialog.show()
            }
        }
    }

    override fun init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        setContentView(R.layout.activity_regist_info)
        sex.setOnClickListener(this)
        occupation.setOnClickListener(this)
        labe.setOnClickListener(this)
        btn.setOnClickListener(this)
        head_pic.setOnClickListener(this)
        back.setOnClickListener(this)

        sexPV.setPicker(sexList)
        occupationPV.setPicker(occupationList)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == LABE_REQUEST_CODE){
            if(resultCode == Activity.RESULT_OK){
                labes = data?.getStringArrayExtra("characters")
                val s = labes?.fold(data?.getStringExtra("year")) { acc, s -> "$acc、$s" }
                tv_labe.text = s
            }
            return
        }
        CropImageUtils.onActivityResult(this, requestCode, resultCode, data, object : CropImageUtils.OnResultListener {
            override fun takePhotoFinish(path: String) {
                //拍照回调，去裁剪
                CropImageUtils.cropPicture(context, path)
            }

            override fun selectPictureFinish(path: String) {
                //相册回调，去裁剪
                CropImageUtils.cropPicture(context, path)
            }

            override fun cropPictureFinish(path: String) {
                picPath = path
                //完成裁剪 上传图片
                Glide.with(context).load(picPath).apply(RequestOptions.circleCropTransform()).into(head_pic)
                uploadImg()
            }
        })
    }

    //上传头像
    fun uploadImg() {
//        val img = File(picPath)
//        val call = OkHttpUtils.post()
//                .url(AppConstant.UPLOAD_HEADIMG_URL + "?token=" + App.token)
//                .addFile("file", img.getName(), img)
//                .addParams("type", "headImg")
//                .build()
//        val pd = LoadingDialog.RequestDialog(this, "正在上传",call)
//        pd.show()
//        call.execute(object : ZeroCallback(pd, context) {
//            @Throws(JSONException::class)
//            override fun onSuccess(json: JSONObject) {
//                //上传成功后删除压缩文件
//                img.delete()
//                MyToast.showShort(context, "修改头像成功！")
//            }
//        })
    }
}

