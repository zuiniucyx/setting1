package com.lixun.topic.room.ui

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.lixun.topic.room.R
import com.lixun.topic.room.utils.Utility
import kotlinx.android.synthetic.main.fragment_mine.*

/**
 * Created by ZeroTao on 2017/11/14.
 */
class MineFragment :BaseFragment(), View.OnClickListener {

    val text_color by lazy { resources.getColor(R.color.text_3) }
    val margin_lr by lazy{ Utility.dip2px(12f) }
    val margin_tb by lazy{ Utility.dip2px(8f) }
    val params by lazy{
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT) }

    override fun onClick(p0: View) {
        when(p0.id){
            R.id.setting -> startActivity(Intent(context,SettingActivity::class.java))
            R.id.my_fans -> startActivity(Intent(context, MyFansActivity::class.java))
            R.id.my_focus -> startActivity(Intent(context, MyFansActivity::class.java).putExtra("isFocus",true))
        }
    }

    override fun initData() {
        my_fans.setOnClickListener(this)
        my_focus.setOnClickListener(this)
        setting.setOnClickListener(this)
        labe.addView(newTab("90后",R.drawable.tab_red))
        labe.addView(newTab("屌丝",R.drawable.tab_blue))
        labe.addView(newTab("吃货",R.drawable.tab_blue))
        labe.addView(newTab("技术宅",R.drawable.tab_blue))
    }

    private fun newTab(name:String,bgRes:Int): TextView {
        val tv = TextView(context)
        tv.text = name
        tv.setTextColor(text_color)
        tv.textSize = 12f
        tv.setBackgroundResource(R.drawable.et_bg)
        tv.gravity = Gravity.CENTER
        tv.setPadding(margin_lr,margin_tb,margin_lr,margin_tb)
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundResource(bgRes)
        tv.layoutParams = params
        return tv
    }

    override fun layoutId() = R.layout.fragment_mine
}