package com.lixun.topic.room.ui

import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.view.View
import android.widget.TextView
import com.lixun.topic.room.R
import com.lixun.topic.room.adapter.RoomAdapter
import com.lixun.topic.room.widget.RoomItemDecoration
import com.lixun.topic.room.widget.WrapRecyclerView

/**
 * Created by ZeroTao on 2017/11/20.
 */
class NavListFragment: LazyFragment(), View.OnClickListener {

    private val rvHot by lazy { realRootView!!.findViewById<WrapRecyclerView>(R.id.rv_hot) }
    private val rvNew by lazy { realRootView!!.findViewById<WrapRecyclerView>(R.id.rv_new) }
    private val moreHot by lazy { realRootView!!.findViewById<TextView>(R.id.more_hot) }
    private val moreNew by lazy { realRootView!!.findViewById<TextView>(R.id.more_new) }

    override fun onClick(v: View) {
        when(v.id){
        }
    }

    override fun onCreateViewLazy(savedInstanceState: Bundle?) {
        super.onCreateViewLazy(savedInstanceState)
        setContentView(R.layout.fragment_nav_list)
        val itemDecoration = RoomItemDecoration()
        //最热房间
        rvHot.layoutManager = GridLayoutManager(context, 3)
        rvHot.adapter = RoomAdapter(context!!)
        rvHot.setHasFixedSize(true)
        rvHot.addItemDecoration(itemDecoration)
        moreHot.setOnClickListener(this)
        //最新房间
        rvNew.layoutManager = GridLayoutManager(context, 3)
        rvNew.adapter = RoomAdapter(context!!)
        rvNew.setHasFixedSize(true)
        rvNew.addItemDecoration(itemDecoration)
        moreNew.setOnClickListener(this)
    }
}