package com.lixun.topic.room.utils

import android.support.annotation.StringRes
import android.widget.Toast
import com.lixun.topic.room.App

/**
 * Created by ZeroTao on 2017/11/18.
 */
object MyToast {
    private val toast = Toast.makeText(App.context, "", Toast.LENGTH_SHORT)

    fun show(msg:String){
        toast.setText(msg)
        toast.show()
    }
    fun show(@StringRes msg:Int){
        toast.setText(App.context.getString(msg))
        toast.show()
    }
}