package com.lixun.topic.room.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.lixun.topic.room.R
import com.lixun.topic.room.utils.MyToast
import com.lixun.topic.room.utils.Utility
import kotlinx.android.synthetic.main.activity_labelling.*

/**
 * Created by ZeroTao on 2017/11/10.
 * 选择标签
 */
class LabellingActivity : BaseActivity(), View.OnClickListener {
    val characterList = listOf(
            Tab("有钱任性"),Tab("普通青年"),
            Tab("非主流"),Tab("工作狂"),
            Tab("屌丝"),Tab("选择困难户"),
            Tab("吃货"),Tab("起床困难户"),
            Tab("萌妹"),Tab("技术宅"),Tab("自拍党"))
    val yearList = listOf("60后","70后","80后","90后","00后")
    val yearViews = mutableListOf<TextView>()
    var currSelected = 3
    var selectedCount = 0
    val text_color by lazy { resources.getColor(R.color.text_3) }

    val margin_lr by lazy{ Utility.dip2px(12f) }
    val margin_tb by lazy{ Utility.dip2px(10f) }
    val params by lazy{
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT) }

    override fun init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        setContentView(R.layout.activity_labelling)
        back.setOnClickListener(this)
        complete.setOnClickListener(this)

        characterList.forEachIndexed { index, tab ->
            val v = newTab(tab.name)
            v.setOnClickListener({
                if (tab.isSelected){
                    tab.isSelected = false
                    v.setTextColor(text_color)
                    v.setBackgroundResource(R.drawable.et_bg)
                    selectedCount--
                }else{
                    if(selectedCount>2){
                        MyToast.show("不能再选啦！！")
                        return@setOnClickListener
                    }
                    tab.isSelected = true
                    v.setTextColor(Color.WHITE)
                    v.setBackgroundResource(R.drawable.tab_blue)
                    selectedCount++
                }
            })
            character_group.addView(v)
        }

        yearList.forEachIndexed { index, s ->
            val v = newTab(s)
            yearViews.add(v)
            v.setOnClickListener({
                if (currSelected != index){
                    v.setTextColor(Color.WHITE)
                    v.setBackgroundResource(R.drawable.tab_red)
                    yearViews[currSelected].setTextColor(text_color)
                    yearViews[currSelected].setBackgroundResource(R.drawable.et_bg)
                    currSelected = index
                }
            })
            year_group.addView(v)
        }
        yearViews[3].setTextColor(Color.WHITE)
        yearViews[3].setBackgroundResource(R.drawable.tab_red)
    }

    private fun newTab(name:String):TextView{
        val tv = TextView(context)
        tv.text = name
        tv.setTextColor(text_color)
        tv.textSize = 12f
        tv.setBackgroundResource(R.drawable.et_bg)
        tv.gravity = Gravity.CENTER
        tv.setPadding(margin_lr,margin_tb,margin_lr,margin_tb)
        tv.layoutParams = params
        return tv
    }

    override fun finish() {
        if(selectedCount>0){
            val list = mutableListOf<String>()
            characterList.forEach {
                if(it.isSelected) list.add(it.name)
            }
            setResult(Activity.RESULT_OK,Intent().putExtra("characters",list.toTypedArray()).putExtra("year",yearList[currSelected]))
        }
        super.finish()
    }

    override fun onClick(v: View) {
        when(v.id){
            R.id.btn -> {
                startActivity(Intent(context, RegistInfoActivity::class.java))
                finish()
            }
            R.id.back,R.id.complete -> finish()
        }
    }

    class Tab{
        val name:String
        var isSelected:Boolean

        constructor(name:String,isSelected:Boolean = false){
            this.name = name
            this.isSelected = isSelected
        }
    }

}