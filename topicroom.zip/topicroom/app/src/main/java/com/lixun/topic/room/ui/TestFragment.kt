package com.lixun.topic.room.ui

import android.annotation.SuppressLint
import com.lixun.topic.room.R
import kotlinx.android.synthetic.main.test.*

/**
 * Created by ZeroTao on 2017/11/7.
 */
@SuppressLint("ValidFragment")
class TestFragment : BaseFragment{
    val msg:String

    constructor(msg:String):super(){
        this.msg = msg
    }

    override fun initData() {
        tv.text = msg
    }

    override fun layoutId() = R.layout.test

}