package com.lixun.topic.room.widget

import android.content.Context
import android.graphics.*
import com.bumptech.glide.Glide
import com.bumptech.glide.load.Transformation
import com.bumptech.glide.load.engine.Resource
import com.bumptech.glide.load.resource.bitmap.BitmapResource
import com.lixun.topic.room.App
import com.lixun.topic.room.utils.Utility
import java.security.MessageDigest

/**
 * Created by ZeroTao on 2017/11/18.
 * Glide圆角图片加载
 * @param dp 圆角半径 默认2dp
 */
class FilletTransform(dp: Int = 2) : Transformation<Bitmap> {
    val radius = Utility.dip2px(dp.toFloat()).toFloat()
    val mBitmapPool = Glide.get(App.context).bitmapPool
    override fun transform(context: Context?, resource: Resource<Bitmap>, outWidth: Int, outHeight: Int): BitmapResource? {
        val source = resource.get()
        val width = source.width
        val height = source.height
        val bitmap = mBitmapPool.get(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint()
        paint.isAntiAlias = true
        paint.shader = BitmapShader(source, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), radius, radius, paint)
        return BitmapResource.obtain(bitmap,mBitmapPool)
    }
    override fun updateDiskCacheKey(messageDigest: MessageDigest?) = Unit

}