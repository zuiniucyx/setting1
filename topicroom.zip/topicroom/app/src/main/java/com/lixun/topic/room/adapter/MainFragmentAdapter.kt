package com.lixun.topic.room.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import com.lhh.apst.library.AdvancedPagerSlidingTabStrip
import com.lixun.topic.room.R

/**
 * Created by ZeroTao on 2017/11/7.
 */
class MainFragmentAdapter : FragmentStatePagerAdapter, AdvancedPagerSlidingTabStrip.IconTabProvider{

    val fragmentList :MutableList<Fragment>
    val navTitles = listOf("消息","房间","我的")
    val navIcons = listOf(
            R.drawable.nav_icon_message_default,
            R.drawable.nav_icon_home_default,
            R.drawable.nav_icon_me_default)
    val navSelectIcons = listOf(
            R.drawable.nav_icon_message_highlight,
            R.drawable.nav_icon_home_highlight,
            R.drawable.nav_icon_me_highlight)

    constructor(fm:FragmentManager,fragmentList:MutableList<Fragment>):super(fm){
        this.fragmentList = fragmentList
    }
    override fun getPageTitle(position: Int) = navTitles.get(position)
    override fun getItem(position: Int) = fragmentList.get(position)
    override fun getCount() = navTitles.size
    override fun getPageIconBounds(position: Int) = null
    override fun <T : Any?> getPageIcon(position: Int) = navIcons[position] as T
    override fun <T : Any?> getPageSelectIcon(position: Int) = navSelectIcons[position] as T
}