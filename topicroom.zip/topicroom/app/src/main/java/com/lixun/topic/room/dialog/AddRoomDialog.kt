package com.lixun.topic.room.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.View
import com.lixun.topic.room.R
import kotlinx.android.synthetic.main.dialog_add_room.*

/**
 * Created by ZeroTao on 2017/11/21.
 * 创建房间
 */

class AddRoomDialog(context: Activity): Dialog(context, com.lixun.topic.room.R.style.customDialog), View.OnClickListener {
    private val activity = context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_add_room)
        create_room_normal.setOnClickListener(this)
        create_room_meeting.setOnClickListener(this)
        create_room_pwd.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.create_room_normal -> {
                CreateRoomDialog(activity).show()
                dismiss()
            }
            R.id.create_room_meeting -> {
                CreateRoomDialog(activity,1).show()
                dismiss()
            }
            R.id.create_room_pwd -> {
                CreateRoomDialog(activity,2).show()
                dismiss()
            }
        }
    }
}
