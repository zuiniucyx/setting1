package com.lixun.topic.room.widget

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.support.annotation.ColorRes
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import com.lixun.topic.room.App
import com.lixun.topic.room.utils.Utility

/**
 * Created by ZeroTao on 2017/11/17.
 * RecyclerView grid分割线
 */
class GridItemDecoration :RecyclerView.ItemDecoration {
    private val dividerHeight:Int
    private var dividerPaint:Paint?=null

    constructor(@ColorRes colorRes: Int, dp:Float){
        dividerPaint = Paint()
        dividerPaint!!.color = App.context.resources.getColor(colorRes)
        this.dividerHeight= Utility.dip2px(dp)
    }

    constructor(dp:Float){
        this.dividerHeight= Utility.dip2px(dp)
    }

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State?) {
        val layoutManager = parent.layoutManager
        if(layoutManager is GridLayoutManager){
            val itemCount = layoutManager.itemCount
            val spanCount = layoutManager.spanCount
            val position = parent.getChildAdapterPosition(view)
            //最后一竖不画线
            if(position%spanCount != spanCount-1){
                outRect.right = dividerHeight
            }
            //最后一行不画线
            val lastLineCount = itemCount%spanCount
            if(lastLineCount==0 ) {
                if(itemCount-position>spanCount)
                    outRect.bottom = dividerHeight
            }else if(itemCount-position>lastLineCount){
                outRect.bottom = dividerHeight
            }
        }
    }
    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State?) {
        if(dividerPaint==null){
            return
        }
        val childCount = parent.childCount
        val layoutManager = parent.layoutManager
        if(layoutManager is GridLayoutManager){
            val spanCount = layoutManager.spanCount
            for(i in 0 until childCount){
                val view = parent.getChildAt(i)
                val left = view.left.toFloat()
                var right = view.right.toFloat()
                val top = view.top.toFloat()
                val bottom = view.bottom.toFloat()
                //当前行最后一个，右边不画竖线
                if(i%spanCount != spanCount-1) {
                    // 画竖线
                    c.drawRect(right,top,right + dividerHeight,bottom,dividerPaint)
                    right+=dividerHeight
                }
                //最后一行不画线
                val lastLineCount = childCount%spanCount
                if(lastLineCount==0 ) {
                    if(childCount-i>spanCount) c.drawRect(left,bottom,right,bottom+dividerHeight,dividerPaint)
                }else if(childCount-i>lastLineCount){
                    // 画横线
                    c.drawRect(left,bottom,right,bottom+dividerHeight,dividerPaint)
                }
            }
        }
    }
}