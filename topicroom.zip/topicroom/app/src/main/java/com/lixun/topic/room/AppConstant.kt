package com.lixun.topic.room

/**
 * Created by ZeroTao on 2017/11/9.
 */

object AppConstant {
    val TOKEN = "token"
    val PERM_REQUEST_CODE = 11
}
