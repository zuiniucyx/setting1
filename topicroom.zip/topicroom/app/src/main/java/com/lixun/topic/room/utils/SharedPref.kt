package com.lixun.topic.room.utils

import android.content.SharedPreferences
import com.lixun.topic.room.App

/**
 * Created by ZeroTao on 2017/11/7.
 */

object SharedPref {
    private val sharedPreferences: SharedPreferences
    private val editor: SharedPreferences.Editor

    init {
        sharedPreferences = App.context.getSharedPreferences("config", 0)
        editor = sharedPreferences.edit()
    }

    fun remove(key: String) {
        editor.remove(key).apply()
    }

    fun contains(key: String) = sharedPreferences.contains(key)

    fun clear() {
        editor.clear().apply()
    }

    fun putInt(key: String, value: Int) {
        editor.putInt(key, value).apply()
    }

    fun getInt(key: String, defValue: Int) = sharedPreferences.getInt(key, defValue)

    fun putLong(key: String, value: Long) {
        editor.putLong(key, value).apply()
    }

    fun getLong(key: String, defValue: Long) = sharedPreferences.getLong(key, defValue)

    fun putBoolean(key: String, value: Boolean) {
        editor.putBoolean(key, value).apply()
    }

    fun getBoolean(key: String, defValue: Boolean) = sharedPreferences.getBoolean(key, defValue)

    fun putString(key: String, value: String) {
        editor.putString(key, value).apply()
    }

    fun getString(key: String, defValue: String) = sharedPreferences.getString(key, defValue)

}
