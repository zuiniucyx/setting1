package com.lixun.topic.room.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import com.lixun.topic.room.R
import com.lixun.topic.room.ui.NavListActivity
import com.lixun.topic.room.utils.MyToast
import com.lixun.topic.room.widget.SelectorPopup
import kotlinx.android.synthetic.main.dialog_create_room.*



/**
 * Created by ZeroTao on 2017/11/22.
 * type  0、普通房 1、会议房 2、密码房
 */
 class CreateRoomDialog(context: Activity,type:Int = 0) :Dialog (context, R.style.customDialog) {

    private val activity = context
    private val type = type
    private val isHideSelector = context is NavListActivity || type == 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_create_room)
        root.setOnClickListener({dismiss()})
        content.setOnClickListener({})
        val mWindowAttributes = window!!.attributes
        mWindowAttributes.width = WindowManager.LayoutParams.MATCH_PARENT
        mWindowAttributes.height = WindowManager.LayoutParams.MATCH_PARENT
        //板块内 不显示选择
        if(isHideSelector){
            topic_plate.visibility = View.GONE
            topic_type.visibility = View.GONE
            line1.visibility = View.GONE
            line2.visibility = View.GONE
        }else{
            var currPlate = 0
            val plates = arrayOf("情感","职场","娱乐")
            val types = arrayOf(arrayOf("家庭","两性","单身","知己"),arrayOf("吐槽","心得"),arrayOf("音乐","游戏","八卦","户外","运动"))
            val spType = object : SelectorPopup(context,topic_type,types[currPlate]){
                override fun onItemSelected(index: Int) {
                    tv_type.text = types[currPlate][index]
                }
            }
            val spPlate = object : SelectorPopup(context,topic_plate,plates){
                override fun onItemSelected(index: Int) {
                    tv_plate.text = plates[index]
                    currPlate = index
                    spType.changeItems(types[index])
                    tv_type.text = types[index][0]
                }
            }
            topic_plate.setOnClickListener({
                spPlate.show()
            })
            topic_type.setOnClickListener({
                spType.show()
            })
        }
        when(type){
            0 -> {
                tv_title.text = "创建普通房"
                pwd.visibility = View.GONE
                line4.visibility = View.GONE
                btn.setOnClickListener({
                    val name = et_name.text.toString().trim()
                    if(name.isEmpty()){
                        MyToast.show("请输入房间名")
                        return@setOnClickListener
                    }
                    MyToast.show("创建成功")
                    dismiss()
                })
            }
            1 -> {
                tv_title.text = "创建会议房"
                btn.setOnClickListener({
                    val name = et_name.text.toString().trim()
                    val pwd = et_pwd.text.toString().trim()
                    if(name.isEmpty()){
                        MyToast.show("请输入房间名")
                        return@setOnClickListener
                    }
                    if(pwd.length!=6){
                        MyToast.show("请输入6位数密码")
                        return@setOnClickListener
                    }
                    MyToast.show("创建成功")
                    dismiss()
                })
            }
            2 -> {
                tv_title.text = "创建密码房"
                btn.setOnClickListener({
                    val name = et_name.text.toString().trim()
                    val pwd = et_pwd.text.toString().trim()
                    if(name.isEmpty()){
                        MyToast.show("请输入房间名")
                        return@setOnClickListener
                    }
                    if(pwd.length!=6){
                        MyToast.show("请输入6位数密码")
                        return@setOnClickListener
                    }
                    MyToast.show("创建成功")
                    dismiss()
                })
            }
        }
    }

}
