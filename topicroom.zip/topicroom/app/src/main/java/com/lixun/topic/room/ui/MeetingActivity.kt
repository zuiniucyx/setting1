package com.lixun.topic.room.ui

import android.graphics.Rect
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.adapter.RoomAdapter
import com.lixun.topic.room.utils.Utility
import kotlinx.android.synthetic.main.activity_meeting.*

/**
 * Created by ZeroTao on 2017/11/21.
 */
class MeetingActivity :BaseActivity(), View.OnClickListener {
    val adapter by lazy { RoomAdapter(context) }

    override fun onClick(v: View) {
        when(v.id){
            R.id.back -> finish()
        }
    }

    override fun init() {
        setContentView(R.layout.activity_meeting)
        recyclerView.layoutManager = GridLayoutManager(context, 3)
        adapter.count = 33
        recyclerView.adapter = adapter
        recyclerView.setHasFixedSize(true)
        recyclerView.addItemDecoration(object : RecyclerView.ItemDecoration(){
            private val dividerHeight = Utility.dip2px(12f)
            override fun getItemOffsets(outRect: Rect, view: View?, parent: RecyclerView?, state: RecyclerView.State?) {
                outRect.set(0,dividerHeight,dividerHeight,0)
            }
        })
        back.setOnClickListener(this)
    }
}