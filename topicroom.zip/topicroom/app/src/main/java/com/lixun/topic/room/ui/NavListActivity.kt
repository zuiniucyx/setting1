package com.lixun.topic.room.ui

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import android.view.View
import com.lixun.topic.room.R
import com.lixun.topic.room.dialog.AddRoomDialog
import kotlinx.android.synthetic.main.activity_nav_list.*

/**
 * Created by ZeroTao on 2017/11/20.
 */
class NavListActivity:BaseActivity(), View.OnClickListener {
    val createRoomDialog by lazy{ AddRoomDialog(context)  }
    val index by lazy{ intent.getIntExtra("index",0) }
    var type = 0
    override fun onClick(v: View) {
        when(v.id){
            R.id.back -> finish()
            R.id.add_room -> createRoomDialog.show()
        }
    }

    val fragments = mutableListOf<Fragment>()

    override fun init() {
        setContentView(R.layout.activity_nav_list)
        add_room.setOnClickListener(this)
        val titles : Array<String>
        when(index){
            0 -> {
                titles = arrayOf("家庭","两性","单身","知己")
                tv_title.text = "情感"
            }
            1 -> {
                titles = arrayOf("吐槽","心得")
                tv_title.text = "职场"
            }
            else -> {
                titles = arrayOf("音乐","游戏","八卦","户外","运动")
                tv_title.text = "娱乐"
            }
        }
        back.setOnClickListener(this)
        for(i in 0 until titles.size){
            fragments.add(NavListFragment())
        }
        pager.adapter = object :FragmentPagerAdapter(supportFragmentManager){
            override fun getItem(position: Int) = fragments[position]
            override fun getCount(): Int = titles.size
            override fun getPageTitle(position: Int): CharSequence = titles[position]
        }
        pager.offscreenPageLimit = titles.size
        tabs.setViewPager(pager)
        tabs.setOnPageChangeListener(object:ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(state: Int) = Unit
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) = Unit
            override fun onPageSelected(position: Int) {
                type = position
            }
        })
    }
}