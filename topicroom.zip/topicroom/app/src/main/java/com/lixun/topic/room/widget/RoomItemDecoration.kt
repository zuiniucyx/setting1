package com.lixun.topic.room.widget

import android.graphics.Rect
import android.support.v7.widget.RecyclerView
import android.view.View
import com.lixun.topic.room.utils.Utility

/**
 * Created by ZeroTao on 2017/11/21.
 */
class RoomItemDecoration : RecyclerView.ItemDecoration() {
    private val dividerHeight = Utility.dip2px(12f)
    override fun getItemOffsets(outRect: Rect, view: View?, parent: RecyclerView?, state: RecyclerView.State?) {
        outRect.set(0,0,dividerHeight,dividerHeight)
    }
}
