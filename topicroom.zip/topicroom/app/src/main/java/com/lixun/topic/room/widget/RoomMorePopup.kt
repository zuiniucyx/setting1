package com.lixun.topic.room.widget

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import com.lixun.topic.room.R

/**
 * Created by ZeroTao on 2017/11/21.
 */
class RoomMorePopup(context: Context, val view: View, isManager: Boolean = false) : PopupWindow(), View.OnClickListener {

    init {
        val contentView = LayoutInflater.from(context).inflate(R.layout.popup_room_more, null)
        //这一块只有房主创建房间才有匹配用户，如果用户进入房间就只有消息和分享
        if(isManager){
            val matchUser = contentView.findViewById<View>(R.id.match_user)
            matchUser.visibility = View.VISIBLE
            matchUser.setOnClickListener(this)
        }
        contentView.findViewById<View>(R.id.msg).setOnClickListener(this)
        contentView.findViewById<View>(R.id.share).setOnClickListener(this)

        width = ViewGroup.LayoutParams.WRAP_CONTENT
        height = ViewGroup.LayoutParams.WRAP_CONTENT
        //设置可以获得焦点
        isFocusable = true
        //设置弹窗内可点击
        isTouchable = true
        //设置弹窗外可点击
        isOutsideTouchable = true
        setContentView(contentView)
    }
    override fun onClick(v: View?) {
    }

    /**
     * 显示弹窗列表界面
     */
    fun show() {
        showAsDropDown(view)
    }
}