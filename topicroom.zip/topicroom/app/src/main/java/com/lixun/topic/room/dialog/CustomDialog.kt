package com.lixun.topic.room.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import com.lixun.topic.room.R
import kotlinx.android.synthetic.main.dialog.*

/**
 * Created by ZeroTao on 2017/11/15.
 * 操作-警告对话框
 */

abstract class CustomDialog : Dialog {
    private val msg: String

    constructor(context: Context, resMsg: Int) : super(context, R.style.customDialog) {
        this.msg = context.getString(resMsg)
    }

    constructor(context: Context, msg: String) : super(context, R.style.customDialog) {
        this.msg = msg
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog)
        tv_msg.text = msg
        ok.setOnClickListener {
            dismiss()
            clickOK()
        }
        cancel.setOnClickListener { dismiss() }
    }

    abstract fun clickOK()
}
