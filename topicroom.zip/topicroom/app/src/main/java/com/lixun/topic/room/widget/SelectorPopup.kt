package com.lixun.topic.room.widget

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import com.lixun.topic.room.R
import com.lixun.topic.room.utils.Utility

/**
 * Created by ZeroTao on 2017/11/22.
 * 自定义选择器
 */
abstract class SelectorPopup(context: Context, val view: View, items:Array<String>,width:Int = Utility.dip2px(280f)) : PopupWindow() {
    var currItem = 0
    val contentView:LinearLayout
    val inflate:LayoutInflater

    init {
        inflate = LayoutInflater.from(context)
        contentView = inflate.inflate(R.layout.popup_selected, null) as LinearLayout
        this.width = width
        this.height = ViewGroup.LayoutParams.WRAP_CONTENT
        addItemViews(items)
        //设置可以获得焦点
        isFocusable = true
        //设置弹窗内可点击
        isTouchable = true
        //设置弹窗外可点击
        isOutsideTouchable = true
        setContentView(contentView)
    }

    fun changeItems(items:Array<String>){
        currItem = 0
        contentView.removeAllViews()
        addItemViews(items)
    }

    private fun addItemViews(items:Array<String>){
        items.forEachIndexed { index, s ->
            val item = inflate.inflate(R.layout.item_menu, null)
            val tv = item.findViewById<TextView>(R.id.tv)
            tv.text = s
            tv.setOnClickListener {
                contentView.getChildAt(currItem).visibility = View.VISIBLE
                currItem = index
                item.visibility = View.GONE
                onItemSelected(index)
                dismiss()
            }
            contentView.addView(item)
        }
        contentView.getChildAt(0).visibility = View.GONE
    }

    abstract fun onItemSelected(index: Int)

    /**
     * 显示弹窗列表界面
     */
    fun show() {
        showAsDropDown(view)
    }

}