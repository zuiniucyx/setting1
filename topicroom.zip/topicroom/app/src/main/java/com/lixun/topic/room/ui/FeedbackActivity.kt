package com.lixun.topic.room.ui

import android.view.View
import com.lixun.topic.room.R
import kotlinx.android.synthetic.main.activity_regist.*

/**
 * Created by ZeroTao on 2017/11/15.
 * 帮助与反馈
 */
class FeedbackActivity :BaseActivity(), View.OnClickListener {

    override fun onClick(v: View) {
        when(v.id){
            R.id.btn -> {
//                startActivity(Intent(context,RegistInfoActivity::class.java))
                finish()
            }
            R.id.back -> finish()
        }
    }

    override fun init() {
        setContentView(R.layout.activity_feedback)
        back.setOnClickListener(this)
        btn.setOnClickListener(this)
    }
}